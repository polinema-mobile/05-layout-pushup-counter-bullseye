# Push Up Counter

## Screenshot App
### Main Menu
![Main Menu](assets/mainmenu.png)
### Push Up Menu
![Push Up Menu](assets/pushmenu.png)
